**********************************************
* Author: ideawu
* Link: http://www.ideawu.net/
* Cpy - Cpy provides you a way to write Python
*       codes in C syntax!
**********************************************

* Run the samples
	$ ./cpy samples/hello.cpy

* Compile Antlr grammar files
	$ make antlr
